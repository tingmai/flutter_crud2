
class Category {
  final int? id;
  final String name;

  const Category({this.id,required this.name});

  //object to map 
  Map<String,dynamic> toMap(){
    return {
      'id':id,
      'name':name
    };
  }

  //map to object
  factory Category.fromMap(Map<String,dynamic> map){
    return  Category(
      id: map['id'],
      name: map['name']
    );
  }
}