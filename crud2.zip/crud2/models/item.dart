import 'dart:typed_data';

class Item {
  final int? id;
  final String category;
  final String name;
  final double price;
  final String description;
  final Uint8List? imageData;
  final String? imagePath;

  Item({
    this.id,
    required this.category,
    required this.name,
    required this.price,
    required this.description,
    this.imageData,
    this.imagePath,
  });

  // Convert Item Object to Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'category': category,
      'name': name,
      'price': price,
      'description': description,
      'image_data': imageData,
      'image_path': imagePath,
    };
  }

  // Convert Map to Item Object
  factory Item.fromMap(Map<String, dynamic> map) {
    return Item(
      id: map['id'],
      category: map['category'],
      name: map['name'],
      price: (map['price'] as num).toDouble(),
      description: map['description'],
      imageData: map['image_data'] != null
          ? Uint8List.fromList(
              map['image_data'] as List<int>,
            )
          : null,
      imagePath: map['image_path'],
    );
  }
}