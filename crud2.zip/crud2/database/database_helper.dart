import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  // 1. Private constructor to prevent external instantiation
  DatabaseHelper._internal();

  // 2. The single static instance of the class
  static final DatabaseHelper instance = DatabaseHelper._internal();

  // 3. Cache the database object
  static Database? _database;

  // 4. Getter to access the database instance (lazily initializes if null)
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  // 5. Initialize the database directory path and file name
  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'my_db.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  // 6. Create the schema when the database is generated for the first time
  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        description TEXT,
        image_data BLOB,
        image_path TEXT
        
      )
    ''');
  }

  

  // Optional: Close connection safely
  Future<void> close() async {
    final db = await instance.database;
    db.close();
  }
}
