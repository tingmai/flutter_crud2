import '../database/database_helper.dart';
import '../models/item.dart';

class ItemRepository {

  // CREATE
  Future<int> create(Item item) async {
    final db =
        await DatabaseHelper.instance.database;

    return await db.insert(
      'items',
      item.toMap(),
    );
  }

  // READ ALL
  Future<List<Item>> getAll() async {
    final db =
        await DatabaseHelper.instance.database;

    final result = await db.query(
      'items',
      orderBy: 'id DESC',
    );

    return result.map((e) => Item.fromMap(e)).toList();
  }

  // READ SINGLE
  Future<Item?> getById(int id) async {
    final db =
        await DatabaseHelper.instance.database;

    final result = await db.query(
      'items',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (result.isNotEmpty) {
      return Item.fromMap(result.first);
    }

    return null;
  }

  // UPDATE
  Future<int> update(Item item) async {
    final db =
        await DatabaseHelper.instance.database;

    return await db.update(
      'items',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  // DELETE
  Future<int> delete(int id) async {
    final db =
        await DatabaseHelper.instance.database;

    return await db.delete(
      'items',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}