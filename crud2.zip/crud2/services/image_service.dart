
import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

class ImageService {

  final ImagePicker picker = ImagePicker();

  Future<Map<String, dynamic>?> pickImage() async {

    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );

    if (image == null) return null;

    final Uint8List bytes = await image.readAsBytes();

    return {
      'image_data': bytes,
      'image_path': image.path,
    };
  }
}