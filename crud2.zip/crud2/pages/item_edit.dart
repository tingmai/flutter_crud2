import 'package:flutter/material.dart';
import 'package:flutter_application_1/crud2/models/item.dart';
import 'package:flutter_application_1/crud2/repositories/item_repository.dart';
import 'package:flutter_application_1/crud2/services/image_service.dart';
import 'dart:typed_data';

class ItemEditPage extends StatefulWidget {
  final int id;

  const ItemEditPage({
    super.key,
    required this.id,
  });

  @override
  State<ItemEditPage> createState() =>
      _ItemEditPageState();
}

class _ItemEditPageState extends State<ItemEditPage> {

  final repository = ItemRepository();
  final imageService = ImageService();

  final _formKey = GlobalKey<FormState>();

  final categoryController = TextEditingController();
  final nameController = TextEditingController();
  final priceController = TextEditingController();
  final descriptionController = TextEditingController();

  Uint8List? imageData;
  String? imagePath;

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadItem();
  }

  Future<void> loadItem() async {

    final item = await repository.getById(widget.id);

    if (!mounted) return;

    if (item != null) {
      categoryController.text = item.category;
      nameController.text = item.name;
      priceController.text = item.price.toString();
      descriptionController.text = item.description;

      imageData = item.imageData;
      imagePath = item.imagePath;
    }

    setState(() {
      isLoading = false;
    });
  }

  Future<void> uploadImage() async {

    final image = await imageService.pickImage();

    if (image != null) {
      setState(() {
        imageData = image['image_data'];
        imagePath = image['image_path'];
      });
    }
  }

  Future<void> updateItem() async {

    if (!_formKey.currentState!.validate()) return;

    final item = Item(
      id: widget.id,
      category: categoryController.text,
      name: nameController.text,
      price: double.parse(priceController.text),
      description: descriptionController.text,
      imageData: imageData,
      imagePath: imagePath,
    );

    await repository.update(item);

    if (!mounted) return;

    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    categoryController.dispose();
    nameController.dispose();
    priceController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Item'),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),

        child: Form(
          key: _formKey,

          child: Column(
            children: [

              TextFormField(
                controller: categoryController,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Item Name',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Price',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || double.tryParse(v) == null) {
                    return 'Enter a valid price';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: descriptionController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              if (imageData != null)
                Image.memory(
                  imageData!,
                  height: 150,
                  width: 150,
                  fit: BoxFit.cover,
                ),

              ElevatedButton.icon(
                onPressed: uploadImage,
                icon: const Icon(Icons.upload),
                label: const Text('Change Image'),
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: updateItem,
                  child: const Text('Update Item'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}