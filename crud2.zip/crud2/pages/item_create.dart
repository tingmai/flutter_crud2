import 'package:flutter/material.dart';
import 'package:flutter_application_1/crud2/models/item.dart';
import 'package:flutter_application_1/crud2/repositories/item_repository.dart';
import 'package:flutter_application_1/crud2/services/image_service.dart';
import 'dart:typed_data';

class ItemCreatePage extends StatefulWidget {
  const ItemCreatePage({super.key});

  @override
  State<ItemCreatePage> createState() =>
      _ItemCreatePageState();
}

class _ItemCreatePageState extends State<ItemCreatePage> {

  final _formKey = GlobalKey<FormState>();

  final categoryController = TextEditingController();
  final nameController = TextEditingController();
  final priceController = TextEditingController();
  final descriptionController = TextEditingController();

  final repository = ItemRepository();
  final imageService = ImageService();

  Uint8List? imageData;
  String? imagePath;

  Future<void> uploadImage() async {

    final image = await imageService.pickImage();

    if (image != null) {
      setState(() {
        imageData = image['image_data'];
        imagePath = image['image_path'];
      });
    }
  }

  Future<void> saveItem() async {

    if (!_formKey.currentState!.validate()) return;

    final item = Item(
      category: categoryController.text,
      name: nameController.text,
      price: double.parse(priceController.text),
      description: descriptionController.text,
      imageData: imageData,
      imagePath: imagePath,
    );

    await repository.create(item);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Item Created Successfully')),
    );

    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    categoryController.dispose();
    nameController.dispose();
    priceController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Item'),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),

        child: Form(
          key: _formKey,

          child: Column(
            children: [

              TextFormField(
                controller: categoryController,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Item Name',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Required' : null,
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Price',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || double.tryParse(v) == null) {
                    return 'Enter a valid price';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: descriptionController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              if (imageData != null)
                Image.memory(
                  imageData!,
                  height: 150,
                  width: 150,
                  fit: BoxFit.cover,
                ),

              ElevatedButton.icon(
                onPressed: uploadImage,
                icon: const Icon(Icons.upload),
                label: const Text('Upload Image'),
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: saveItem,
                  child: const Text('Save Item'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}