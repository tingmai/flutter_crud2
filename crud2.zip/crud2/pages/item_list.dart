import 'package:flutter/material.dart';
import 'package:flutter_application_1/crud2/models/item.dart';
import 'package:flutter_application_1/crud2/pages/item_create.dart';
import 'package:flutter_application_1/crud2/pages/item_edit.dart';
import 'package:flutter_application_1/crud2/repositories/item_repository.dart';


class ItemIndexPage extends StatefulWidget {
  const ItemIndexPage({super.key});

  @override
  State<ItemIndexPage> createState() =>
      _ItemIndexPageState();
}

class _ItemIndexPageState extends State<ItemIndexPage> {

  final repository = ItemRepository();

  List<Item> items = [];

  @override
  void initState() {
    super.initState();
    loadItems();
  }

  Future<void> loadItems() async {
    final result = await repository.getAll();

    if (!mounted) return;

    setState(() {
      items = result;
    });
  }

  Future<void> deleteItem(int id) async {

    await repository.delete(id);

    await loadItems();
  }

  Future<void> openCreatePage() async {

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const ItemCreatePage(),
      ),
    );

    if (result == true) {
      loadItems();
    }
  }

  Future<void> openEditPage(int id) async {

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ItemEditPage(id: id),
      ),
    );

    if (result == true) {
      loadItems();
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text('Item Management'),
      ),

      body: items.isEmpty
          ? const Center(child: Text('No Items Found'))

          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: items.length,

              itemBuilder: (context, index) {

                final item = items[index];

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),

                  child: ListTile(

                    leading: item.imageData != null
                        ? Image.memory(
                            item.imageData!,
                            width: 65,
                            height: 65,
                            fit: BoxFit.cover,
                          )
                        : const Icon(
                            Icons.image,
                            size: 50,
                          ),

                    title: Text(item.name),

                    subtitle: Text(
                      '${item.category}\n\$${item.price.toStringAsFixed(2)}',
                    ),

                    isThreeLine: true,

                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'edit') {
                          openEditPage(item.id!);
                        } else if (value == 'delete') {
                          deleteItem(item.id!);
                        }
                      },

                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 'edit',
                          child: Text('Edit'),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Text('Delete'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

      floatingActionButton: FloatingActionButton(
        onPressed: openCreatePage,
        child: const Icon(Icons.add),
      ),
    );
  }
}